set schema app;
create table T_XBBNHGU_LOGINREGISTER(MAIL_ID varchar(30) primary key ,PASSWORD varchar(30),USER_NAME varchar(10),USER_TYPE varchar(30));
insert into T_XBBNHGU_LOGINREGISTER values('admin@gmail.com','admin123','imadmin','admin');
drop table T_XBBNHGU_LOGINREGISTER;
delete from  T_XBBNHGU_LOGINREGISTER where USER_NAME='thiru';
update T_XBBNHGU_LOGINREGISTER set USER_TYPE='user' where USER_NAME='';
select * from T_XBBNHGU_LOGINREGISTER;
ALTER table T_XBBNHGU_LOGINREGISTER DROP COLUMN MOBILE_NUMBER;
ALTER TABLE T_XBBNHGU_LOGINREGISTER
  MODIFY USER_NAME varchar(30);