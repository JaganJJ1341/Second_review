package loginregister;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import recipemanagement.ConnectionManager;

import recipemanagement.recipebean;

public class loginregisterappcumdao 
{
	Connection conn = ConnectionManager.getConnection();
	Scanner sc=new Scanner(System.in);
	PreparedStatement stmt = null;
	List<recipebean> holdingsList = null;
	ResultSet resultSet =null;
  loginregisterbean loginRegisterBean =new loginregisterbean(); 	
  public boolean register(String mailid,String password,String username,String usertype)
  {
	  loginRegisterBean.setMailId(mailid);
	  loginRegisterBean.setPassword(password);
	  loginRegisterBean.setUserName(username);
	  if(usertype.equals("admin"))
		  return false;
	  else
	  {
	  try
	  {
		  /*ConnectionManager.setschema(conn,stmt);*/
		  String s1="insert into T_XBBNHGU_LOGINREGISTER values(?,?,?,?)";
		  stmt = conn.prepareStatement(s1);
		  stmt.setString(1, loginRegisterBean.getMailId());
		  stmt.setString(2, loginRegisterBean.getPassword());
		  stmt.setString(3, loginRegisterBean.getUserName());
		  stmt.setString(4, usertype);
		  resultSet=stmt.executeQuery();
		  if(resultSet.next()!=false)
		  {
			  
			  return true;
			 
			 
		  }
	  }
	  catch(SQLException e)
	  {
		  return false;
		
	  }
	  return true;
	  }
  }
  public loginregisterbean login(loginregisterbean loginRegisterBean)
  {
	  try
	  {
	  String s1="select * from T_XBBNHGU_LOGINREGISTER where MAIL_ID=? and PASSWORD =? and USER_TYPE=?";
	  stmt = conn.prepareStatement(s1);
	  stmt.setString(1, loginRegisterBean.getMailId());
	  stmt.setString(2, loginRegisterBean.getPassword());
	  stmt.setString(3, loginRegisterBean.getUserType());
	  resultSet=stmt.executeQuery();
	  if(resultSet.next()!=false)
	  { 
		  loginRegisterBean.setUserName(resultSet.getString("USER_NAME")); 
		  loginRegisterBean.setStatus(true);
		  return loginRegisterBean;
	  }
	  else
	  {
		  loginRegisterBean.setStatus(false);
		  return loginRegisterBean;
	  }
	  }
	  catch(SQLException e)
	  {
		  e.printStackTrace();
	  }
	  return loginRegisterBean;
	  
  }
  public String getUserName(String mailid)
  {
	  try
	  {
		  String s1="Select USER_NAME from T_XBBNHGU_LOGINREGISTER where MAIL_ID=?";
		  stmt=conn.prepareStatement(s1);
		  stmt.setString(1,mailid);
		  resultSet=stmt.executeQuery();
		  while(resultSet.next()!=false)
		  {  
		  return resultSet.getString(1);
		  }
	  }
	  catch(SQLException e)
	  {
		  e.printStackTrace();
	  }
	return "viewer";
  }
}
