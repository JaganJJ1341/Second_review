package loginregister;

public class loginregisterbean 
{

    private String mobilenumber ;
    private boolean status;
    private String mailid,password,username,usertype ;
    /*public StockBean(String stockId,String  stockName){
    	this.stockId = stockId;
    	this.stockName = stockName;
    	
    }*/
	public String getMobileNumber() {
		return mobilenumber;
	}
	public void setMobileNumber(String stockId) {
		this.mobilenumber = stockId;
	}
	public String getMailId() {
		return mailid;
	}
	public void setMailId(String stockName) {
		this.mailid = stockName;
	}
	public void setPassword(String password) {
		this.password = password;
	
   }
	public String getUserName() {
		return username;
}
	public void setUserName(String password) {
		this.username = password;
	
    
}
	public String getPassword() {
		return password;
}
	public String getUserType()
	{
		return usertype;
	}
	public void setUserType(String usertype)
	{
		this.usertype=usertype;
	}
	public void setStatus(boolean status)
	{
		this.status=status;
	}
	public boolean getStatus()
	{
		return status;
	}
}
