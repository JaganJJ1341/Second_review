create table T_XBBNHGU_RECIPECOMMENT(MAIL_ID varchar(30) not null,RECIPE_ID integer not null,RECIPE_COMMENT clob,constraint T_XBBNHGU_RECIPECOMMENT primary key(MAIL_ID,RECIPE_ID));
drop table T_XBBNHGU_RECIPECOMMENT;
insert into T_XBBNHGU_RECIPECOMMENT values('editor@gmail.com',2,'vafjv');



select * from T_XBBNHGU_RECIPECOMMENT;
create table T_XBBNHGU_RECIPECOMMENT(MAIL_ID varchar(30),RECIPE_ID integer,RECIPE_COMMENT clob,constraint T_XBBNHGU_RECIPECOMMENT primary key(MAIL_ID,RECIPE_ID));

alter table T_XBBNHGU_RECIPECOMMENT drop constraint T_XBBNHGU_RECIPECOMMENT;
alter table T_XBBNHGU_RECIPECOMMENT modify DATE_OF_COMMENT varchar(200);
truncate table T_XBBNHGU_RECIPECOMMENT;
select * from T_XBBNHGU_RECIPECOMMENT where RECIPE_ID=1;