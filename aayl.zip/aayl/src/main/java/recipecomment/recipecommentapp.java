package recipecomment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import recipemanagement.ConnectionManager;
import recipemanagement.recipebean;

public class recipecommentapp
{
	Connection conn = ConnectionManager.getConnection();
	Scanner sc=new Scanner(System.in);
	PreparedStatement stmt = null;
	ResultSet resultSet =null;
	List<String> holdingsList = null;
	List<recipecommentbean>holdingList=null;
	recipecommentbean recipeCommentBean=new recipecommentbean();
 public boolean addComment(String mailid,int recipeid,String comment)
 {
	 
	 try
	 {
		 String s1="insert into T_XBBNHGU_RECIPECOMMENT values(?,?,?,?)";
		 recipeCommentBean.setMailId(mailid);
		 recipeCommentBean.setRecipeId(recipeid);
		 recipeCommentBean.setComment(comment);
		 Date date = new Date();
		 recipeCommentBean.setDate(date.toString());
		 stmt=conn.prepareStatement(s1);
		 stmt.setString(1, recipeCommentBean.getMailId());
		 stmt.setInt(2, recipeCommentBean.getRecipeId());
		 stmt.setString(3, recipeCommentBean.getComment());
		 stmt.setString(4, recipeCommentBean.getDate());
		 stmt.executeQuery();
		 System.out.println("Comment Added Successfully");
		 return true;
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
		 return false;
	 }
	 
 }
 public void removeComment(String comment)
 {
	 try
	 {
		 String s1="delete from T_XBBNHGU_COMMENT where RECIPE_COMMENT=?";
		 stmt=conn.prepareStatement(s1);
		 stmt.setString(1, comment);
		 stmt.executeQuery();
		 System.out.println("Comment Removed Successfully");
		 
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
	 }
 }
 public void viewCommentByMailId(String mailId)
 {
	 try
	 {
	 String s1="select RECIPE_COMMENT from T_XBBNHGU_RECIPECOMMENT where MAIL_ID=?";
	 stmt=conn.prepareStatement(s1);
	 stmt.setString(1, mailId);
	 holdingsList = new ArrayList<String>();
	 resultSet=stmt.executeQuery();
	 if(resultSet.next()!=false)
	 {
		 holdingsList.add(resultSet.getString("RECIPE_COMMENT"));
	 }
	 Iterator<String> itr =  holdingsList.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
	 }
		 
	 
 }
 public void viewCommentByRecipeId(int recipeId)
 {
	 try
	 {
	 String s1="select RECIPE_COMMENT from T_XBBNHGU_RECIPECOMMENT where RECIPE_ID=?";
	 stmt=conn.prepareStatement(s1);
	 stmt.setInt(1,recipeId);
	 holdingsList = new ArrayList<String>();
	 resultSet=stmt.executeQuery();
	 if(resultSet.next()!=false)
	 {
		 holdingsList.add(resultSet.getString("RECIPE_COMMENT"));
	 }
	 Iterator<String> itr =  holdingsList.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
	 }
		 
	 
 }
 public List<recipecommentbean> seeComment(int recipeid)
 {
	 try
	 {
		 String s1="select * from T_XBBNHGU_RECIPECOMMENT where RECIPE_ID=?";
		 stmt=conn.prepareStatement(s1);
		 stmt.setInt(1,recipeid);
		 holdingList = new ArrayList<recipecommentbean>();
		 resultSet=stmt.executeQuery();
		 while(resultSet.next())
		 {
			 recipecommentbean recipeCommentBean1=new recipecommentbean();
			 recipeCommentBean1.setMailId(resultSet.getString("MAIL_ID"));
			 recipeCommentBean1.setRecipeId(resultSet.getInt("RECIPE_ID"));
			 recipeCommentBean1.setComment(resultSet.getString("RECIPE_COMMENT"));
			 recipeCommentBean1.setDate(resultSet.getString("DATE_OF_COMMENT"));
			 holdingList.add(recipeCommentBean1);
			 System.out.println(holdingList);
		 }
		 
	 }
	 catch(SQLException e)
	 {
		e.printStackTrace(); 
	 }
	
	 return holdingList;
 }
 
 
 
 
}
