package recipecomment;

public class recipecommentbean 
{
	  private String mailid,comment,date ;
	    
	    private int recipeid ;
	    /*public StockBean(String stockId,String  stockName){
	    	this.stockId = stockId;
	    	this.stockName = stockName;
	    	
	    }*/
		public int getRecipeId() {
			return recipeid;
		}
		public void setRecipeId(int stockId) {
			this.recipeid = stockId;
		}
		public String getMailId() {
			return mailid;
		}
		public void setMailId(String stockName) {
			this.mailid = stockName;
		}
		public String getComment() {
			return comment;
	}
		public void setComment(String comment) {
			this.comment = comment;
}
		public String getDate() {
			return date;
	}
		public void setDate(String date) {
			this.date = date;
}
}