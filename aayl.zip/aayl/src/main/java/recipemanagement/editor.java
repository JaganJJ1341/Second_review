/*package recipemanagement;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import recipecomment.recipecommentapp;

public class editor
{
	Scanner sc=new Scanner(System.in);
	recipedao recipeDao=new recipedao();
	public void editor(String mailid)
	{
		System.out.println("Congratulation!! You have logged in as editor successfully"); 	
		System.out.println("Enter choice");
		System.out.println("1.Insert Recipes");
		System.out.println("2.Update Recipes");
		System.out.println("3.Delete Recipes");
		System.out.println("4.View Recipes");	
	   int choice =sc.nextInt();
		if(choice==1 || choice ==3)
			System.out.println("You can't insert or delete recipes as an editor");
		else if(choice==2)
		{
			 recipebean recipeBean =new recipebean();
			  System.out.println("What do you want to update ?");
			  System.out.println("1.Recipe Name");
			  System.out.println("2.Recipe Type");
			  int updateChoice=sc.nextInt();
			  if(updateChoice==1)
			  {
				  System.out.println("Enter Recipe ID to be updated");
				  int recipeId=sc.nextInt();
				  recipeBean.setRecipeId(recipeId);
				  System.out.println("Enter new name for the Recipe");
				  sc.nextLine();
				  String recipeName=sc.nextLine();
				  recipeBean.setRecipeName(recipeName);
				  recipeDao.updateRecipeName(recipeBean);
			  }
			  else if(updateChoice==2)
			  {
				  System.out.println("Enter Recipe ID to be updated");
				  int recipeId=sc.nextInt();
				  recipeBean.setRecipeId(recipeId);
				  System.out.println("Enter new type for the Recipe");
				  sc.nextLine();
				  String recipeType=sc.nextLine();
				  recipeBean.setRecipeType(recipeType);
				  recipeDao.updateRecipeType(recipeBean);
			  }
			  else
			  {
				  System.out.println("Invalid Choice");
			  }
		}
		else if(choice==4)
		{
			 recipebean recipeBean =new recipebean();
			 System.out.println("Enter the Recipe ID to be viewed");
			 int recipeId=sc.nextInt();
			 recipeBean.setRecipeId(recipeId);
			 List<recipebean> holdingList = recipeDao.viewRecipe(recipeBean);
			 Iterator<recipebean> itr =  holdingList.iterator();
				while(itr.hasNext())
				{
					
				    recipeBean = itr.next();
					System.out.println(recipeBean.getRecipeId()+ " "+ recipeBean.getRecipeName()+ " "+ recipeBean.getRecipeType());
				}
				System.out.println("Do you wish to add comments");
				 System.out.println("1.Yes");
				 System.out.println("2.No");
				 int commentswish=sc.nextInt();
				 if(commentswish==1)
				 {	 
				 System.out.println("1.Add Comment");
				// System.out.println("2.Remove Comment");
				 System.out.println("2.View Comments");
				 int commentchoice=sc.nextInt();
				 if(commentchoice==1)
				 {
					 recipecommentapp recipeCommentApp=new recipecommentapp();
					 System.out.println("Enter your comment");
					 sc.nextLine();
					 String comment=sc.nextLine();
					 recipeCommentApp.addComment(mailid,recipeId,comment);
				 }
				 else if(commentchoice==2)
				 {
					 recipecommentapp recipeCommentApp=new recipecommentapp();
					 System.out.println("Enter the comment you have to remove");
					 sc.nextLine();
					 String comment=sc.nextLine();
					 recipeCommentApp.removeComment(comment);
				 }
			 else if(commentchoice==2)
				 {
					 recipecommentapp recipeCommentApp=new recipecommentapp();
					 System.out.println("1.View Comments by mail id");
					 System.out.println("2.View Comments by recipe id");
					 int commentviewchoice=sc.nextInt();
					 if(commentviewchoice==1)
					 {
						 System.out.println("Enter mail id whose comment you want to view");
						 sc.nextLine();
						 String mailId=sc.nextLine();
						 recipeCommentApp.viewCommentByMailId(mailId);
					 }
					 else
					 {
						 System.out.println("Enter recipe id to view comments under it");
						 
						 int recipeid=sc.nextInt();
						 recipeCommentApp.viewCommentByRecipeId(recipeid);	 
					 }
				 }  
				 }
				 else
				 {
					 System.out.println("Thank you for visiting our portal");
				 }
			}	
	}
}
*/