
create table T_XBBNHGU_RECIPE (RECIPE_ID integer primary key,RECIPE_NAME varchar(20),RECIPE_TYPE varchar(20));
alter table T_XBBNHGU_RECIPE drop column RECIPE_IMAGE;
update T_XBBNHGU_RECIPE set RECIPE_TYPE='North Indian' where RECIPE_NAME='Poori';
update T_XBBNHGU_RECIPE set RECIPE_NAME='Chilli+sauce' where RECIPE_NAME='chilli+sauce';
select * from T_XBBNHGU_RECIPE order by RECIPE_ID;
ALTER TABLE T_XBBNHGU_RECIPE ADD RECIPE_IMAGE blob;
insert into T_XBBNHGU_RECIPE(RECIPE_ID,RECIPE_NAME,RECIPE_TYPE) values(10,'chilli+sauce','shouth indian');
delete from T_XBBNHGU_RECIPE where RECIPE_ID>9;
select max(RECIPE_ID) from T_XBBNHGU_RECIPE