/*
package recipemanagement;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import loginregister.loginregisterappcumdao;
import recipecomment.recipecommentapp;

public class recipeapp 
{
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		loginregisterappcumdao loginRegisterAppCumDao =new loginregisterappcumdao();
		recipedao recipeDao = new recipedao();
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to Online Recipe Management Portal");
		System.out.println("1.Login");
		System.out.println("2.Register");
		int option=sc.nextInt();
		if(option==1)
		{
		System.out.println("Enter the registered mail id");
		sc.nextLine();
		String mailid=sc.nextLine();
		System.out.println("Enter the password");
		String password=sc.nextLine();
		System.out.println("Enter the type of user");
		String usertype=sc.nextLine();
		if(loginRegisterAppCumDao.login(mailid,password,usertype))
		{
		if(usertype.equals("admin"))
		{	
			admin admin=new admin();
			admin.admin(mailid);

		}
	else if(usertype.equals("editor"))
	    {
		editor editor=new editor();
		editor.editor(mailid);
		}
	
	else if(usertype.equals("user"))
	{
		user user=new user();
		user.user(mailid);
	}
	else
	{
		System.out.println("Invalid credentials or Register before logging in");
	}
	
	}
	}
	else
	{
		
		System.out.println("Enter the mail id to register");;
		sc.nextLine();
		String mailid=sc.nextLine();
		System.out.println("Enter the password you wish");
		String password=sc.nextLine();
		System.out.println("Enter the username you want");
		String username=sc.nextLine();
		System.out.println("Enter your mobile number");
		String mobilenumber=sc.nextLine();
		System.out.println("Enter the user type you want to login as");
		String usertype=sc.nextLine();
		if(usertype.equals("admin"))
			System.out.println("You can't be an admin");
		else
		{
			if(loginRegisterAppCumDao.register(mailid,password,username,mobilenumber,usertype))
				System.out.println("Registration successful");
			else
				  System.out.println("mail id is already registered");
		}
		
	}
	}
}

*/