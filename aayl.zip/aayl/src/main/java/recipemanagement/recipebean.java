package recipemanagement;

public class recipebean {
	
    private int recipeId ;
    private String recipeName,recipeType ;
    /*public StockBean(String stockId,String  stockName){
    	this.stockId = stockId;
    	this.stockName = stockName;
    	
    }*/
	public int getRecipeId() {
		return recipeId;
	}
	public void setRecipeId(int stockId) {
		this.recipeId = stockId;
	}
	public String getRecipeName() {
		return recipeName;
	}
	public void setRecipeName(String stockName) {
		this.recipeName = stockName;
	}
	public void setRecipeType(String stockName) {
		this.recipeType = stockName;
	
    
}
	public String getRecipeType() {
		return recipeType;
}
}