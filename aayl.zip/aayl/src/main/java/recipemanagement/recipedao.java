package recipemanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import recipeprocedure.recipeprocedureapp;
import recipeprocedure.recipeproceduredao;
import recipetype.recipetypeapp;
public class recipedao
{
	//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		Scanner sc=new Scanner(System.in);
		PreparedStatement stmt = null;
		List<recipebean> holdingsList = null;
		ResultSet resultSet =null;
		public boolean insertRecipes(recipebean recipeBean)
		{
		try 
	    {
			String s="select max(RECIPE_ID) from T_XBBNHGU_RECIPE";
			stmt=conn.prepareStatement(s);
			resultSet=stmt.executeQuery();
			resultSet.next();
			int recipeidm=resultSet.getInt(1);
			recipeBean.setRecipeId(recipeidm+1);
			String s1="insert into T_XBBNHGU_RECIPE values(?,?,?)";
			stmt = conn.prepareStatement(s1);
			stmt.setInt(1,recipeBean.getRecipeId());
			stmt.setString(2, recipeBean.getRecipeName());
			stmt.setString(3, recipeBean.getRecipeType());
			resultSet=stmt.executeQuery();
			System.out.println("Row Inserted Successfully");
			return true;
			
		}
		
		 catch (SQLException e) 
		{
					// TODO Auto-generated catch block
			 e.printStackTrace();;
			 return false;
				
		}
		}
		
		/*public void updateRecipeName(recipebean recipeBean)
		{
			try
			{
				recipeprocedureapp recipeProcedureApp =new recipeprocedureapp();
				String s1="update T_XBBNHGU_RECIPE set RECIPE_NAME = ? where RECIPE_ID=?";
				stmt = conn.prepareStatement(s1);
				stmt.setString(1, recipeBean.getRecipeName());
				stmt.setInt(2, recipeBean.getRecipeId());
				resultSet=stmt.executeQuery();
				recipeProcedureApp.updateRecipeProcedure(recipeBean.getRecipeId(),recipeBean.getRecipeName());
				System.out.println("Recipe Name updated Successfully in recipe table");
			}
			catch (SQLException e) 
			{
						// TODO Auto-generated catch block
				System.out.println("Enter a valid Recipe Id to Update records");
					
			}*/
		
		public void updateRecipeType(recipebean recipeBean)
		{
			try
			{
				String s1="Select * from T_XBBNHGU_RECIPE where RECIPE_ID=?";
				stmt = conn.prepareStatement(s1);
				stmt.setInt(1,recipeBean.getRecipeId());
				resultSet=stmt.executeQuery();
				resultSet.next();
				String recipetype=resultSet.getString("RECIPE_TYPE");
			    s1="update T_XBBNHGU_RECIPE set RECIPE_TYPE = ? where RECIPE_TYPE=?";
				stmt = conn.prepareStatement(s1);
				stmt.setString(1, recipeBean.getRecipeType());
				stmt.setString(2, recipetype);
				stmt.executeQuery();
				recipetypeapp recipeTypeApp = new recipetypeapp();
				recipeTypeApp.updateRecipeType(recipetype,recipeBean.getRecipeType());	
				System.out.println("Recipe Type updated Successfully in Recipe Table");
				
				
			}
			catch (SQLException e) 
			{
						// TODO Auto-generated catch block
				e.printStackTrace();
				//System.out.println("Enter a valid Recipe Id to Update records");
					
			}
		}
		public boolean deleteRecipe(recipebean recipeBean)
		{
			try
			{
				recipeprocedureapp recipeProcedureApp =new recipeprocedureapp();
				String s1="delete from T_XBBNHGU_RECIPE where RECIPE_ID=?";
				stmt = conn.prepareStatement(s1);
				stmt.setInt(1, recipeBean.getRecipeId());
				resultSet=stmt.executeQuery();
				recipeProcedureApp.deleteRecipeProcedure(recipeBean.getRecipeId());
				if(resultSet.next())
				System.out.println("Recipe Deleted Successfully");
				return true;	
			}
			catch (SQLException e) 
			{
						// TODO Auto-generated catch block
				System.out.println("Enter a valid Recipe Id to Delete records");
				return false;
					
			}
		}
		public recipebean viewRecipe(recipebean recipeBean)
		{
			try
			{
				String s1="select * from T_XBBNHGU_RECIPE where RECIPE_ID=?";
				stmt = conn.prepareStatement(s1);
				stmt.setInt(1, recipeBean.getRecipeId());
				resultSet=stmt.executeQuery();
				holdingsList = new ArrayList<recipebean>();
				if(resultSet.next()!=false)
				{	
				
					
					recipeBean.setRecipeId(resultSet.getInt("RECIPE_ID"));
					recipeBean.setRecipeName(resultSet.getString("RECIPE_NAME"));
					recipeBean.setRecipeType(resultSet.getString("RECIPE_TYPE"));
					holdingsList.add(recipeBean);
					/*System.out.println("Do you want to see the recipe type and procedure ?");
					System.out.println("1.Yes");
					System.out.println("2.No");
					int viewrecipetypeandprocedurechoice=1;
					if(viewrecipetypeandprocedurechoice==1)
					{
					 recipeproceduredao recipeProcedureDao=new recipeproceduredao();
					 recipeProcedureDao.viewRecipeProcedure(recipeProcedureBean);
					}*/
				}
			   
			
				
			else
				{
					System.out.println("Recipe ID not found");		
				}
			}
			catch (SQLException e) 
			{
					e.printStackTrace();	
	
					   
			}
			return recipeBean;
		}
		public List<recipebean> searchRecipe(recipebean recipeBean)
		{
			System.out.println(recipeBean.getRecipeName());
			try
			{
				String s1="select * from T_XBBNHGU_RECIPE where RECIPE_NAME LIKE ?";
				stmt = conn.prepareStatement(s1);
				stmt.setString(1,"%"+recipeBean.getRecipeName()+"%");
				resultSet=stmt.executeQuery();
				holdingsList = new ArrayList<recipebean>();
				if(resultSet.next()!=false)
				{	
				    recipeBean.setRecipeId(resultSet.getInt("RECIPE_ID"));
					recipeBean.setRecipeName(resultSet.getString("RECIPE_NAME"));
					recipeBean.setRecipeType(resultSet.getString("RECIPE_TYPE"));
					holdingsList.add(recipeBean);
				}
				else
				{
					System.out.println("Recipe not found");	
				    
				}
		 }
			catch (SQLException e) 
			{
					e.printStackTrace();	
	
					   
			}
			System.out.println(holdingsList);
			return holdingsList;
}
}

	
	
	
	
	
	
	

