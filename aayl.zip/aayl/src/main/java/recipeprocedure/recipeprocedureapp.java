package recipeprocedure;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import recipemanagement.recipebean;

public class recipeprocedureapp
{
	Scanner sc=new Scanner(System.in);
	recipeprocedurebean recipeProcedureBean =new recipeprocedurebean();
	recipeproceduredao recipeProcedureDao=new recipeproceduredao();
  public void insertRecipeProcedure(int recipeId,String recipeName)
  {
	  
	  
	  recipeProcedureBean.setRecipeId(recipeId);
	  recipeProcedureBean.setRecipeName(recipeName);
	  System.out.println("Enter the ingredients of the recipe");
	  String recipeIngredients=sc.nextLine();
	  recipeProcedureBean.setRecipeIngredients(recipeIngredients);
	  System.out.println("Enter the procedure of the recipe");
	  String recipeProcedure=sc.nextLine();
	  recipeProcedureBean.setRecipeProcedure(recipeProcedure);
	  recipeProcedureDao.insertRecipeProcedure(recipeProcedureBean);
  }
  /*public void updateRecipeProcedure(int recipeId,String recipeName)
  {
	  
	  recipeProcedureBean.setRecipeId(recipeId);
	  recipeProcedureBean.setRecipeName(recipeName);
	  System.out.println("Do you want to update recipe's ingredients and procedure?");
	  System.out.println("1.Yes");
	  System.out.println("2.No");
	  int updateRecipeProcedurechoice=sc.nextInt();
	  if(updateRecipeProcedurechoice==1)
	  {		  
	  System.out.println("Enter the new ingredients of the recipe");
	  sc.nextLine();
	  String recipeIngredients=sc.nextLine();
	  recipeProcedureBean.setRecipeIngredients(recipeIngredients);
	  System.out.println("Enter the new procedure of the recipe");
	  String recipeProcedure=sc.nextLine();
	  recipeProcedureBean.setRecipeProcedure(recipeProcedure);
	  recipeProcedureDao.updateRecipeProcedure(recipeProcedureBean,updateRecipeProcedurechoice);
	  }
	  else
	  recipeProcedureDao.updateRecipeProcedure(recipeProcedureBean,updateRecipeProcedurechoice);
  }*/
  public void deleteRecipeProcedure(int recipeId)
  {
	  recipeProcedureBean.setRecipeId(recipeId);
	  recipeProcedureDao.deleteRecipeProcedure(recipeProcedureBean);
  }
  /*public void viewRecipeProcedure(int recipeId)
  {
	  recipeProcedureBean.setRecipeId(recipeId);
	  List<recipeprocedurebean> holdingList =recipeProcedureDao.viewRecipeProcedure(recipeProcedureBean);
	  Iterator<recipeprocedurebean> itr =  holdingList.iterator();
			while(itr.hasNext())
			{
				
			    recipeProcedureBean = itr.next();
				System.out.println(recipeProcedureBean.getRecipeId()+ " "+ recipeProcedureBean.getRecipeName()+ " "+ recipeProcedureBean.getRecipeIngredients()+" "+recipeProcedureBean.getRecipeProcedure());
			}
			
	}*/
  
}

