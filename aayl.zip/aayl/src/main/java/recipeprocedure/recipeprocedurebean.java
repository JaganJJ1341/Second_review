package recipeprocedure;

public class recipeprocedurebean
{

    private int recipeId ;
    private String recipeName,recipeIngredients,recipeProcedure ;
    /*public StockBean(String stockId,String  stockName){
    	this.stockId = stockId;
    	this.stockName = stockName;
    	
    }*/
	public int getRecipeId() {
		return recipeId;
	}
	public void setRecipeId(int stockId) {
		this.recipeId = stockId;
	}
	public String getRecipeName() {
		return recipeName;
	}
	public void setRecipeName(String stockName) {
		this.recipeName = stockName;
	}
	public void setRecipeIngredients(String stockName) {
		this.recipeIngredients = stockName;
	}
	public String getRecipeIngredients() {
		return recipeIngredients;
		
}
	public void setRecipeProcedure(String stockName) {
		this.recipeProcedure = stockName;
	}
	public String getRecipeProcedure() {
		return recipeProcedure;
}
}