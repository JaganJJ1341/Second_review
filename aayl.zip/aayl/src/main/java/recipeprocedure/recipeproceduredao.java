package recipeprocedure;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import recipemanagement.ConnectionManager;
import recipetype.recipetypebean;

public class recipeproceduredao 
{
Connection conn = ConnectionManager.getConnection();
PreparedStatement stmt = null;
ResultSet resultSet =null;
List<recipeprocedurebean> holdingsList = null;
 public boolean insertRecipeProcedure(recipeprocedurebean recipeProcedureBean)
 {
	 try
	 {   String s="select max(RECIPE_ID) from T_XBBNHGU_RECIPEPROCEDURE";
	     stmt=conn.prepareStatement(s);
	     resultSet=stmt.executeQuery();
	     resultSet.next();
	     int recipeid=resultSet.getInt(1);
	     recipeProcedureBean.setRecipeId(recipeid+1);
	     String s1="insert into T_XBBNHGU_RECIPEPROCEDURE values(?,?,?,?)";
		 stmt = conn.prepareStatement(s1);
		 stmt.setInt(1, recipeProcedureBean.getRecipeId());
		 stmt.setString(2, recipeProcedureBean.getRecipeName());
		 stmt.setString(3,recipeProcedureBean.getRecipeIngredients());
		 stmt.setString(4, recipeProcedureBean.getRecipeProcedure());
		 stmt.executeQuery();
		 System.out.println("Procedure of the recipe added successfully");
		 return true;
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
		 return false;
	 }
 }
 public boolean updateRecipeProcedure(recipeprocedurebean recipeProcedureBean)
 {
	 try
	 {
		 int choice=1;
		 if(choice==2)
		 {	 
		 String s2="update T_XBBNHGU_RECIPEPROCEDURE set RECIPE_NAME=? where RECIPE_ID=?";
		 stmt=conn.prepareStatement(s2);
		 stmt.setString(1, recipeProcedureBean.getRecipeName());
		 stmt.setInt(2, recipeProcedureBean.getRecipeId());
		 stmt.executeQuery();
		 }
		 else
		 {	 
		 String s1="update T_XBBNHGU_RECIPEPROCEDURE set RECIPE_INGREDIENTS=? where RECIPE_ID=?";
		 stmt = conn.prepareStatement(s1);
		 stmt.setString(1, recipeProcedureBean.getRecipeIngredients());
		 stmt.setInt(2, recipeProcedureBean.getRecipeId());
		 stmt.executeQuery();
		 String s="update T_XBBNHGU_RECIPEPROCEDURE set RECIPE_PROCEDURE=? where RECIPE_ID=?";
		 stmt = conn.prepareStatement(s);
		 stmt.setString(1,recipeProcedureBean.getRecipeProcedure());
		 stmt.setInt(2, recipeProcedureBean.getRecipeId());
		 stmt.executeQuery();
		 return true;
		 }
	 }
	 catch(SQLException e)
	 {
		 
		 e.printStackTrace();
		 return false;
	 }
	 return true;
 }
 public boolean deleteRecipeProcedure(recipeprocedurebean recipeProcedureBean)
 {
	 try
	 {
	 String s1="delete from T_XBBNHGU_RECIPEPROCEDURE where RECIPE_ID=?";
	 stmt=conn.prepareStatement(s1);
	 stmt.setInt(1, recipeProcedureBean.getRecipeId());
	 stmt.executeQuery();
	 System.out.println("Recipe Procedure removed successfully");
	 return true;
	 
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
		 return false;
	 }
	 
	 
 }
 public recipeprocedurebean viewRecipeProcedure(recipeprocedurebean recipeProcedureBean)
 {
	 try
		{
		    
			String s1="select * from T_XBBNHGU_RECIPEPROCEDURE where RECIPE_ID=?";
			stmt = conn.prepareStatement(s1);
			stmt.setInt(1, recipeProcedureBean.getRecipeId());
		 resultSet=stmt.executeQuery();
		   if(resultSet.next()!=false)
			{	
			 
	
				recipeProcedureBean.setRecipeId(resultSet.getInt("RECIPE_ID"));
				recipeProcedureBean.setRecipeName(resultSet.getString("RECIPE_NAME"));
				recipeProcedureBean.setRecipeIngredients(resultSet.getString("RECIPE_INGREDIENTS"));
				recipeProcedureBean.setRecipeProcedure(resultSet.getString("RECIPE_PROCEDURE"));
				//holdingsList.add(recipeProcedureBean);
				
			}
		   else
			{
				System.out.println("Recipe Procedure not found");		
			}
		}
		catch (SQLException e) 
		{
				e.printStackTrace();	

	    }
	    
		return recipeProcedureBean;
 }
 
}
