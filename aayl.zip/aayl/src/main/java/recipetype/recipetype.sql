create table T_XBBNHGU_RECIPETYPE(RECIPE_TYPE varchar(20) primary key,TYPE_DESCRIPTION clob,CHIEF_INGREDIENTS clob,PLACE_OF_ORIGIN varchar(20));
drop table T_XBBNHGU_RECIPETYPE;
insert into T_XBBNHGU_RECIPETYPE values('chinese','includes the cuisines mainly found in the china,Hong kong','pastas,soups,pastry','China,Taiwan'); 
delete from T_XBBNHGU_RECIPETYPE where RECIPE_TYPE='antarctic';
select * from T_XBBNHGU_RECIPETYPE;
update T_XBBNHGU_RECIPETYPE set PLACE_OF_ORIGIN='North China Plain' where PLACE_OF_ORIGIN='salem'; 