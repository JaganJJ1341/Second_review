package recipetype;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class recipetypeapp 
{
	Scanner sc=new Scanner(System.in);
	recipetypedao recipeTypeDao=new recipetypedao();
	public void insertRecipeType(String recipeType)
	{
		
	     recipetypebean recipeTypeBean=new recipetypebean();
			recipeTypeBean.setRecipeType(recipeType);
			System.out.println("Enter the description of the type");
			String typedescription=sc.nextLine();
			recipeTypeBean.setTypeDescription(typedescription);
			System.out.println("Enter the chief ingredients of the type");
			String chiefingredients=sc.nextLine();
			recipeTypeBean.setChiefIngredients(chiefingredients);
			System.out.println("Enter the place of orgin of the type");
			String placeoforgin=sc.nextLine();
			recipeTypeBean.setPlaceOfOrgin(placeoforgin);
			recipeTypeDao.insertRecipeType(recipeTypeBean);
	   }
	     public void updateRecipeType(String recipeType,String newrecipetype)
		  {
		      recipetypebean recipeTypeBean=new recipetypebean();
		      recipeTypeBean.setRecipeType(recipeType);
		      System.out.println("Enter Description of the type to  update");
			  String typedescription=sc.nextLine();
			  recipeTypeBean.setTypeDescription(typedescription);
			  System.out.println("Enter Chief Ingredients of the type to  update");
			  String chiefIngredients=sc.nextLine();
			  recipeTypeBean.setChiefIngredients(chiefIngredients);
			  System.out.println("Enter Place of orgin of the type to  update");
			  String placeoforgin=sc.nextLine();
			  recipeTypeBean.setPlaceOfOrgin(placeoforgin);
			  recipeTypeDao.updateRecipeType(recipeTypeBean,newrecipetype);
		  }
	   /*  public void viewRecipeType(String recipetype)
	     {
	    	 recipetypebean recipeTypeBean =new recipetypebean();
			 recipeTypeBean.setRecipeType(recipetype);
			 List<recipetypebean> holdingList = recipeTypeDao.viewRecipeType(recipeTypeBean);
			 Iterator<recipetypebean> itr =  holdingList.iterator();
				while(itr.hasNext())
				{
					
				    recipeTypeBean = itr.next();
					System.out.println(recipeTypeBean.getRecipeType()+ " "+ recipeTypeBean.getTypeDescription()+ " "+ recipeTypeBean.getChiefIngredients()+" "+ recipeTypeBean.getPlaceOfOrgin());
				}
				
	     }*/
	  
	}


