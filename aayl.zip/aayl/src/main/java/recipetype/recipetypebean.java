package recipetype;

public class recipetypebean {
	
    
    private String chiefingredients,recipeType,typedescription,placeoforgin;
    private boolean status;
    
    /*public StockBean(String stockId,String  stockName){
    	this.stockId = stockId;
    	this.stockName = stockName;
    	
    }*/
	public String getTypeDescription() {
		return typedescription;
	}
	public void setTypeDescription(String stockid) {
		this.typedescription = stockid;
	}
	public String getChiefIngredients() {
		return chiefingredients;
	}
	public void setChiefIngredients(String stockName) {
		this.chiefingredients = stockName;
	}
	public void setRecipeType(String stockName) {
		this.recipeType = stockName;
	}
	public String getRecipeType() {
		return recipeType;
}
	public String getPlaceOfOrgin() {
		return placeoforgin;
	}
	public void setPlaceOfOrgin(String stockName) {
		this.placeoforgin = stockName;
}
	public boolean getStatus()
	{
		return status;
	}
	public void setStatus(boolean status)
	{
		this.status=status;
	}
}