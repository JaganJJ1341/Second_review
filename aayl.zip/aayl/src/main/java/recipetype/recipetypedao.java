package recipetype;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import recipemanagement.ConnectionManager;


public class recipetypedao 
{
    Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	ResultSet resultSet =null;
	List<recipetypebean> holdingsList = null;
 public boolean insertRecipeType(recipetypebean recipeTypeBean )
 {
	 try
	 {
	 String s1="insert into T_XBBNHGU_RECIPETYPE values(?,?,?,?)";
	 stmt = conn.prepareStatement(s1);
	 stmt.setString(1, recipeTypeBean.getRecipeType());
	 stmt.setString(2, recipeTypeBean.getTypeDescription());
	 stmt.setString(3, recipeTypeBean.getChiefIngredients());
	 stmt.setString(4, recipeTypeBean.getPlaceOfOrgin());
	 stmt.executeQuery();
	 System.out.println("Recipe Type added successfully");
	 return true;
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
		 return false;
	 }
 }
 
 public void updateRecipeType(recipetypebean recipeTypeBean,String newrecipetype)
 {
	 try
	 {
	 String s1="update  T_XBBNHGU_RECIPETYPE set TYPE_DESCRIPTION=? where RECIPE_TYPE=?";
	 stmt = conn.prepareStatement(s1);
	 stmt.setString(1, recipeTypeBean.getTypeDescription());
	 stmt.setString(2, recipeTypeBean.getRecipeType());
	 stmt.executeQuery();
	 String s2="update  T_XBBNHGU_RECIPETYPE set CHIEF_INGREDIENTS=? where RECIPE_TYPE=?";
	 stmt = conn.prepareStatement(s2);
	 stmt.setString(1, recipeTypeBean.getChiefIngredients());
	 stmt.setString(2, recipeTypeBean.getRecipeType());
	 stmt.executeQuery();
	 String s3="update  T_XBBNHGU_RECIPETYPE set PLACE_OF_ORIGIN= ? where RECIPE_TYPE=?";
	 stmt = conn.prepareStatement(s3);
	 stmt.setString(1, recipeTypeBean.getPlaceOfOrgin());
	 stmt.setString(2, recipeTypeBean.getRecipeType());
	 stmt.executeQuery();
	 String s4="update  T_XBBNHGU_RECIPETYPE set RECIPE_TYPE= ? where RECIPE_TYPE=?";
	 stmt = conn.prepareStatement(s4);
	 stmt.setString(1, newrecipetype);
	 stmt.setString(2, recipeTypeBean.getRecipeType());
	 stmt.executeQuery();
	 System.out.println("Recipe Type table updated successfully");
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
	 }
	 
 }
 public recipetypebean viewRecipeType(recipetypebean recipeTypeBean)
	{
	   
		try
		{
			String s1="select * from T_XBBNHGU_RECIPETYPE where RECIPE_TYPE=?";
			stmt = conn.prepareStatement(s1);
			stmt.setString(1, recipeTypeBean.getRecipeType());
			resultSet=stmt.executeQuery();
			holdingsList = new ArrayList<recipetypebean>();
		   
			if(resultSet.next()!=false)
			{	
			
				
				recipeTypeBean.setRecipeType(resultSet.getString("RECIPE_TYPE"));
				recipeTypeBean.setTypeDescription(resultSet.getString("TYPE_DESCRIPTION"));
				recipeTypeBean.setChiefIngredients(resultSet.getString("CHIEF_INGREDIENTS"));
				recipeTypeBean.setPlaceOfOrgin(resultSet.getString("PLACE_OF_ORIGIN"));
				holdingsList.add(recipeTypeBean);
				recipeTypeBean.setStatus(true);
			}
		   
		else
			{
				System.out.println("Recipe Type not found");
				recipeTypeBean.setStatus(false);
			}
		}
		catch (SQLException e) 
		{
				e.printStackTrace();	

	    }
		return recipeTypeBean;
	}
 
}
